package sirsuspect.android.sms;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SirsuspectSMSActivity extends Activity implements OnClickListener{
    /** Called when the activity is first created. */
    EditText etPhone, etMsg;
    Button btnSend;
    String cpno;
    String msg;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        etPhone=(EditText) findViewById(R.id.etphone);
        etMsg=(EditText) findViewById(R.id.etmsg);
        btnSend=(Button) findViewById(R.id.bsend);
        btnSend.setOnClickListener(this);
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.bsend){
			cpno=etPhone.getText().toString();
			msg=etMsg.getText().toString();
			try{
				SmsManager smsManager = SmsManager.getDefault();
		        smsManager.sendTextMessage(cpno, null, msg + " -sirsuspect", null, null);
				Toast.makeText(this, "Message sent!", Toast.LENGTH_LONG).show();
				clear();
			}catch (Exception e){
				Toast.makeText(this, "Message sending failed.",Toast.LENGTH_LONG).show();
				e.printStackTrace();
			}
		}
	}
	private void clear(){
		etPhone.setText("");
		etMsg.setText("");
	}
}