/** Automatically generated file. DO NOT MODIFY */
package sirsuspect.android.sms;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}