package com.code256.safari256;

/**
 * DON'T REMOVE THIS
 * Created by CODE+256 on 2/10/14.
 * Mr.sentio henry
 * codeuganda@yahoo.com
 */
public class Application{
    private String title;
    private long totalDl;
    private int rating;
    private String icon;

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public long getTotalDl() {
        return totalDl;
    }
    public void setTotalDl(long totalDl) {
        this.totalDl = totalDl;
    }
    public int getRating() {
        return rating;
    }
    public void setRating(int rating) {
        this.rating = rating;
    }
    public String getIcon() {
        return icon;
    }
    public void setIcon(String icon) {
        this.icon = icon;
    }
}
